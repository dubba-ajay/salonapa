import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Home, Store, X } from "lucide-react";
import type { Service, Salon } from "@shared/schema";
import type { BookingFormData } from "@/types";

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: Service | null;
  salon: Salon | null;
}

export default function BookingModal({ isOpen, onClose, service, salon }: BookingModalProps) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [serviceType, setServiceType] = useState<'salon' | 'home'>('salon');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [notes, setNotes] = useState('');

  const bookingMutation = useMutation({
    mutationFn: async (bookingData: Omit<BookingFormData, 'serviceId' | 'salonId'>) => {
      if (!service || !salon) throw new Error('Service and salon are required');
      
      const fullBookingData: BookingFormData = {
        ...bookingData,
        serviceId: service.id,
        salonId: salon.id,
      };
      
      await apiRequest('POST', '/api/bookings', fullBookingData);
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: "Your appointment has been successfully booked.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      onClose();
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Booking Failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setServiceType('salon');
    setSelectedDate('');
    setSelectedTime('');
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setNotes('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to book an appointment.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!selectedDate || !selectedTime || !customerName || !customerPhone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (serviceType === 'home' && !customerAddress) {
      toast({
        title: "Address Required",
        description: "Please provide your address for home service.",
        variant: "destructive",
      });
      return;
    }

    bookingMutation.mutate({
      bookingDate: selectedDate,
      bookingTime: selectedTime,
      serviceType,
      customerName,
      customerPhone,
      customerAddress: serviceType === 'home' ? customerAddress : undefined,
      notes,
    });
  };

  const getServicePrice = () => {
    if (!service) return '0';
    return serviceType === 'home' && service.homeServicePrice 
      ? service.homeServicePrice 
      : service.price;
  };

  // Generate available dates (next 7 days)
  const availableDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i);
    return {
      value: date.toISOString().split('T')[0],
      label: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : date.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' })
    };
  });

  // Generate available time slots
  const availableTimeSlots = [
    '09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00'
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Book Service
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Service Selection */}
          <div>
            <Label className="text-base font-semibold">Select Service Type</Label>
            <div className="grid grid-cols-2 gap-3 mt-2">
              <Button
                type="button"
                variant={serviceType === 'salon' ? 'default' : 'outline'}
                className="p-3 h-auto flex flex-col items-center"
                onClick={() => setServiceType('salon')}
              >
                <Store className="w-5 h-5 mb-1" />
                <span className="text-sm font-semibold">Salon Visit</span>
              </Button>
              <Button
                type="button"
                variant={serviceType === 'home' ? 'default' : 'outline'}
                className="p-3 h-auto flex flex-col items-center"
                onClick={() => setServiceType('home')}
                disabled={!salon?.homeServiceAvailable}
              >
                <Home className="w-5 h-5 mb-1" />
                <span className="text-sm font-semibold">Home Visit</span>
              </Button>
            </div>
          </div>

          {/* Date Selection */}
          <div>
            <Label className="text-base font-semibold">Select Date</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {availableDates.slice(0, 3).map((date) => (
                <Button
                  key={date.value}
                  type="button"
                  variant={selectedDate === date.value ? 'default' : 'outline'}
                  className="p-2 text-center"
                  onClick={() => setSelectedDate(date.value)}
                >
                  <div className="text-xs">{date.label}</div>
                </Button>
              ))}
            </div>
          </div>

          {/* Time Selection */}
          <div>
            <Label className="text-base font-semibold">Select Time</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {availableTimeSlots.slice(0, 6).map((time) => (
                <Button
                  key={time}
                  type="button"
                  variant={selectedTime === time ? 'default' : 'outline'}
                  className="p-2 text-sm"
                  onClick={() => setSelectedTime(time)}
                >
                  {time}
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Details */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Your Details</Label>
            <Input
              placeholder="Full Name *"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              required
            />
            <Input
              type="tel"
              placeholder="Mobile Number *"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              required
            />
            {serviceType === 'home' && (
              <Textarea
                placeholder="Address for home visit *"
                rows={3}
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                required
              />
            )}
            <Textarea
              placeholder="Special requests or notes (optional)"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          {/* Booking Summary */}
          {service && salon && (
            <div className="bg-gray-50 rounded-lg p-4">
              <Label className="text-base font-semibold mb-2 block">Booking Summary</Label>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Service:</span>
                  <span className="font-semibold">{service.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Salon:</span>
                  <span className="font-semibold">{salon.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-semibold">{service.duration} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span>Type:</span>
                  <Badge variant="secondary">
                    {serviceType === 'home' ? 'Home Service' : 'Salon Visit'}
                  </Badge>
                </div>
                {selectedDate && selectedTime && (
                  <div className="flex justify-between">
                    <span>Date & Time:</span>
                    <span className="font-semibold">
                      {new Date(selectedDate).toLocaleDateString()} at {selectedTime}
                    </span>
                  </div>
                )}
                <div className="flex justify-between border-t pt-2 font-semibold">
                  <span>Total Amount:</span>
                  <span className="text-primary">₹{getServicePrice()}</span>
                </div>
              </div>
            </div>
          )}

          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-primary to-purple-700"
            disabled={bookingMutation.isPending}
          >
            {bookingMutation.isPending ? 'Booking...' : 'Confirm Booking'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
