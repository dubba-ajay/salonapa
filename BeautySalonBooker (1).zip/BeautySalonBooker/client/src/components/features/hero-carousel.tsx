import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";

const slides = [
  {
    id: 1,
    title: "Professional Men's\nGrooming Services",
    description: "Expert haircuts, beard trims, and styling",
    buttonText: "Book Men's Services",
    link: "/category/mens-hair",
    image: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    gradient: "from-slate-800/80 to-gray-800/60",
    textColor: "text-white",
    buttonColor: "bg-white text-slate-800"
  },
  {
    id: 2,
    title: "Luxury Women's\nBeauty Experience",
    description: "Hair styling, facials, and complete beauty packages",
    buttonText: "Book Beauty Services",
    link: "/category/womens-beauty",
    image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    gradient: "from-rose-600/80 to-pink-600/60",
    textColor: "text-white",
    buttonColor: "bg-white text-rose-600"
  },
  {
    id: 3,
    title: "Premium Nail\nArt Studios",
    description: "Manicures, pedicures, and custom nail designs",
    buttonText: "Book Nail Services",
    link: "/category/nail-studios",
    image: "https://images.unsplash.com/photo-1604654894610-df63bc536371?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    gradient: "from-purple-600/80 to-indigo-600/60",
    textColor: "text-white",
    buttonColor: "bg-white text-purple-600"
  },
  {
    id: 4,
    title: "Expert Makeup\nArtists",
    description: "Bridal, party, and professional makeup services",
    buttonText: "Book Makeup Services",
    link: "/category/makeup-artists",
    image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    gradient: "from-orange-600/80 to-red-600/60",
    textColor: "text-white",
    buttonColor: "bg-white text-orange-600"
  }
];

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const previousSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Slides */}
      <div className="absolute inset-0">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`hero-slide ${index === currentSlide ? 'active' : ''}`}
            style={{
              backgroundImage: `url('${slide.image}')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className={`absolute inset-0 bg-gradient-to-r ${slide.gradient}`}></div>
            <div className={`relative h-full flex items-center justify-center text-center ${slide.textColor} px-4`}>
              <div className="max-w-4xl">
                <h1 className="text-5xl md:text-7xl font-bold mb-6 text-shadow-lg whitespace-pre-line">
                  {slide.title}
                </h1>
                <p className="text-xl md:text-2xl mb-8 text-gray-200">
                  {slide.description}
                </p>
                <Link href={slide.link}>
                  <Button 
                    className={`${slide.buttonColor} px-8 py-4 rounded-full text-lg font-semibold hover:shadow-xl transition-all duration-300 transform hover:scale-105`}
                  >
                    {slide.buttonText}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Controls */}
      <Button
        onClick={previousSlide}
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm rounded-full p-3 text-white hover:bg-white/30 transition-all"
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>

      <Button
        onClick={nextSlide}
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm rounded-full p-3 text-white hover:bg-white/30 transition-all"
      >
        <ChevronRight className="w-6 h-6" />
      </Button>

      {/* Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentSlide 
                ? 'bg-white carousel-indicator active' 
                : 'bg-white/60 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </section>
  );
}
