import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";

const categories = [
  {
    id: 1,
    name: "Men's Hair",
    slug: "mens-hair",
    description: "Professional cuts, styling & grooming",
    image: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    gradient: "from-slate-800/90 to-gray-800/70",
    hoverGradient: "group-hover:from-slate-800/95",
    startingPrice: "₹299"
  },
  {
    id: 2,
    name: "Women's Beauty",
    slug: "womens-beauty",
    description: "Hair, facials & beauty packages",
    image: "https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    gradient: "from-rose-600/90 to-pink-600/70",
    hoverGradient: "group-hover:from-rose-600/95",
    startingPrice: "₹599"
  },
  {
    id: 3,
    name: "Nail Studios",
    slug: "nail-studios",
    description: "Manicures, pedicures & nail art",
    image: "https://images.unsplash.com/photo-1610992015732-2449b76344bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    gradient: "from-purple-600/90 to-indigo-600/70",
    hoverGradient: "group-hover:from-purple-600/95",
    startingPrice: "₹399"
  },
  {
    id: 4,
    name: "Makeup Artists",
    slug: "makeup-artists",
    description: "Bridal, party & professional makeup",
    image: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    gradient: "from-orange-600/90 to-red-600/70",
    hoverGradient: "group-hover:from-orange-600/95",
    startingPrice: "₹799"
  }
];

export default function CategoryCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {categories.map((category) => (
        <Link key={category.id} href={`/category/${category.slug}`}>
          <div className="group cursor-pointer">
            <div className="relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <img 
                src={category.image}
                alt={`${category.name} Services`}
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className={`absolute inset-0 bg-gradient-to-t ${category.gradient} ${category.hoverGradient} transition-all duration-300`}></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
                <p className="text-gray-200 mb-4">{category.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">From {category.startingPrice}</span>
                  <Badge className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 transition-colors">
                    Book Now
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}
