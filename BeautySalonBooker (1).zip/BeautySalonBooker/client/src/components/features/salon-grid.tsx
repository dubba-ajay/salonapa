import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Home, Store } from "lucide-react";
import type { Salon } from "@shared/schema";

interface SalonGridProps {
  categoryId?: number;
  title?: string;
  showAll?: boolean;
}

export default function SalonGrid({ categoryId, title = "Top Rated Salons", showAll = false }: SalonGridProps) {
  const { data: salons, isLoading } = useQuery({
    queryKey: categoryId ? [`/api/salons?categoryId=${categoryId}`] : ['/api/salons'],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="bg-white rounded-2xl shadow-lg overflow-hidden animate-pulse">
            <div className="w-full h-48 bg-gray-200"></div>
            <div className="p-6">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-8 bg-gray-200 rounded w-full"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!salons || salons.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No salons available at the moment.</p>
      </div>
    );
  }

  const displaySalons = showAll ? salons : salons?.slice(0, 6);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displaySalons?.map((salon: Salon) => (
        <div key={salon.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group cursor-pointer">
          <img 
            src={salon.imageUrl || "https://images.unsplash.com/photo-1562322140-8baeececf3df?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"} 
            alt={salon.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="p-6">
            <div className="flex items-start justify-between mb-3">
              <h3 className="text-xl font-bold text-gray-900">{salon.name}</h3>
              <div className="flex items-center bg-green-100 px-2 py-1 rounded-full">
                <Star className="w-4 h-4 text-green-600 mr-1" />
                <span className="text-sm font-semibold text-green-800">{salon.rating}</span>
              </div>
            </div>
            
            <div className="flex items-center text-gray-600 text-sm mb-3">
              <MapPin className="w-4 h-4 mr-1" />
              <span>{salon.city}, {salon.state}</span>
            </div>
            
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500">Professional services</span>
              <span className="text-lg font-bold text-primary">From ₹299</span>
            </div>
            
            <div className="flex space-x-2">
              <Link href={`/salon/${salon.id}`} className="flex-1">
                <Button className="w-full bg-primary hover:bg-purple-700" size="sm">
                  <Store className="w-4 h-4 mr-2" />
                  View Salon
                </Button>
              </Link>
              {salon.homeServiceAvailable && (
                <Button variant="outline" className="flex-1" size="sm">
                  <Home className="w-4 h-4 mr-2" />
                  Home Visit
                </Button>
              )}
            </div>
          </div>
        </div>
        ))}
      </div>
    </div>
  );
}
