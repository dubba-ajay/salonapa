import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Sparkles, Hand, Palette } from "lucide-react";

const quickServices = [
  {
    id: 1,
    name: "Quick Cuts",
    description: "Available in 30 mins",
    price: "₹299",
    icon: Clock,
    category: "Men's Hair"
  },
  {
    id: 2,
    name: "Express Facial",
    description: "Available in 45 mins",
    price: "₹599",
    icon: Sparkles,
    category: "Women's Beauty"
  },
  {
    id: 3,
    name: "Quick Manicure",
    description: "Available in 20 mins",
    price: "₹399",
    icon: Hand,
    category: "Nail Studios"
  },
  {
    id: 4,
    name: "Touch-up Makeup",
    description: "Available in 60 mins",
    price: "₹799",
    icon: Palette,
    category: "Makeup Artists"
  }
];

export default function QuickBook() {
  const handleQuickBook = (serviceName: string) => {
    // In a real app, this would open a booking modal or redirect to booking page
    alert(`Quick booking for ${serviceName} - This would open the booking flow`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {quickServices.map((service) => {
        const IconComponent = service.icon;
        return (
          <div 
            key={service.id} 
            className="glass-morphism rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-3">
                <IconComponent className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">{service.name}</h3>
                <p className="text-sm text-gray-600">{service.description}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-bold text-primary">{service.price}</span>
              <Badge className="bg-green-100 text-green-800">
                Available Now
              </Badge>
            </div>
            
            <Button 
              onClick={() => handleQuickBook(service.name)}
              className="w-full bg-gradient-to-r from-primary to-purple-700 text-white hover:shadow-lg transition-all"
            >
              Book Instantly
            </Button>
          </div>
        );
      })}
    </div>
  );
}
