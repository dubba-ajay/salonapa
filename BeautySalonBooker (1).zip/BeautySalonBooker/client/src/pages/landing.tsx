import { useEffect } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import HeroCarousel from "@/components/features/hero-carousel";
import CategoryCards from "@/components/features/category-cards";
import SalonGrid from "@/components/features/salon-grid";
import QuickBook from "@/components/features/quick-book";

export default function Landing() {
  useEffect(() => {
    document.title = "BeautySalon - Professional Beauty Services";
  }, []);

  return (
    <div className="min-h-screen">
      <Header />
      <HeroCarousel />
      
      {/* Category Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Choose Your <span className="bg-gradient-to-r from-primary to-purple-700 bg-clip-text text-transparent">Service</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Book professional beauty services at top-rated salons or enjoy the convenience of home visits
            </p>
          </div>
          <CategoryCards />
        </div>
      </section>

      {/* Location Based Salons */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Top Rated Stores in Your Area</h2>
              <p className="text-lg text-gray-600">Discover the best beauty professionals near you</p>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-lg transition-colors">
                <i className="fas fa-map-marker-alt text-primary"></i>
                <span>Mumbai, India</span>
              </button>
              <button className="text-primary hover:text-purple-700 font-semibold">View All</button>
            </div>
          </div>
          <SalonGrid />
        </div>
      </section>

      {/* Quick Book Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Quick Book <span className="text-primary">Available Now</span>
            </h2>
            <p className="text-lg text-gray-600">Need urgent service? These salons have immediate availability</p>
          </div>
          <QuickBook />
        </div>
      </section>

      <Footer />
    </div>
  );
}
