import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import SalonGrid from "@/components/features/salon-grid";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Star, Home, Store } from "lucide-react";
import BookingModal from "@/components/features/booking-modal";
import type { Service, Salon } from "@shared/schema";

export default function Category() {
  const { slug } = useParams<{ slug: string }>();
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedSalon, setSelectedSalon] = useState<Salon | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const { data: category, isLoading: categoryLoading } = useQuery({
    queryKey: [`/api/categories/slug/${slug}`],
  });

  const { data: services, isLoading: servicesLoading } = useQuery({
    queryKey: [`/api/services?categoryId=${category?.id}`],
    enabled: !!category?.id,
  });

  const { data: salons, isLoading: salonsLoading } = useQuery({
    queryKey: [`/api/salons?categoryId=${category?.id}`],
    enabled: !!category?.id,
  });

  useEffect(() => {
    if (category) {
      document.title = `${category.name} Services - BeautySalon`;
    }
  }, [category]);

  const handleBookService = (service: Service, salon: Salon) => {
    setSelectedService(service);
    setSelectedSalon(salon);
    setIsBookingModalOpen(true);
  };

  if (categoryLoading || servicesLoading || salonsLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="pt-24 flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="pt-24 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Category Not Found</h1>
            <Link href="/">
              <Button>Go Home</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getColorScheme = (colorScheme: string) => {
    switch (colorScheme) {
      case 'men-slate':
        return 'from-slate-800 to-gray-800';
      case 'women-rose':
        return 'from-rose-600 to-pink-600';
      case 'nail-purple':
        return 'from-purple-600 to-indigo-600';
      case 'makeup-orange':
        return 'from-orange-600 to-red-600';
      default:
        return 'from-primary to-purple-700';
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Category Hero */}
      <section className={`pt-24 pb-16 bg-gradient-to-br ${getColorScheme(category.colorScheme)}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow-lg">
              {category.name}
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              {category.description || `Professional ${category.name.toLowerCase()} services at your convenience`}
            </p>
            <div className="flex justify-center space-x-4">
              <Badge variant="secondary" className="text-sm px-4 py-2">
                {services?.length || 0} Services Available
              </Badge>
              <Badge variant="secondary" className="text-sm px-4 py-2">
                {salons?.length || 0} Partner Salons
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Stores Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SalonGrid 
            categoryId={category.id} 
            title={`${category.name} Stores in Your Area`}
            showAll={true}
          />
        </div>
      </section>



      <Footer />
      
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        service={selectedService}
        salon={selectedSalon}
      />
    </div>
  );
}
