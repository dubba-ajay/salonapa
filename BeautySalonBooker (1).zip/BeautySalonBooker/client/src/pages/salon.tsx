import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Phone, Star, Clock, Home, Store } from "lucide-react";
import BookingModal from "@/components/features/booking-modal";
import type { Service, Salon } from "@shared/schema";

export default function SalonPage() {
  const { id } = useParams<{ id: string }>();
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedSalon, setSelectedSalon] = useState<Salon | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const { data: salon, isLoading: salonLoading } = useQuery({
    queryKey: [`/api/salons/${id}`],
  });

  const { data: services, isLoading: servicesLoading } = useQuery({
    queryKey: [`/api/services?salonId=${salon?.id}`],
    enabled: !!salon?.id,
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: [`/api/salons/${salon?.id}/reviews`],
    enabled: !!salon?.id,
  });

  useEffect(() => {
    if (salon) {
      document.title = `${salon.name} - BeautySalon`;
    }
  }, [salon]);

  const handleBookService = (service: Service) => {
    setSelectedService(service);
    setSelectedSalon(salon);
    setIsBookingModalOpen(true);
  };

  if (salonLoading || servicesLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="pt-24 flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!salon) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="pt-24 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Salon Not Found</h1>
            <Button onClick={() => window.history.back()}>Go Back</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Salon Hero */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                {salon.name}
              </h1>
              <p className="text-xl text-gray-600 mb-6">
                {salon.description || "Premium beauty services with professional care"}
              </p>
              
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-5 h-5 mr-3 text-primary" />
                  <span>{salon.address}, {salon.city}, {salon.state} {salon.pincode}</span>
                </div>
                
                {salon.phone && (
                  <div className="flex items-center text-gray-600">
                    <Phone className="w-5 h-5 mr-3 text-primary" />
                    <span>{salon.phone}</span>
                  </div>
                )}
                
                <div className="flex items-center">
                  <Star className="w-5 h-5 mr-3 text-yellow-500" />
                  <span className="text-lg font-semibold">{salon.rating}</span>
                  <span className="text-gray-500 ml-2">({salon.reviewCount} reviews)</span>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Badge className="bg-green-100 text-green-800 px-4 py-2">
                  <Store className="w-4 h-4 mr-2" />
                  Salon Visits Available
                </Badge>
                {salon.homeServiceAvailable && (
                  <Badge className="bg-blue-100 text-blue-800 px-4 py-2">
                    <Home className="w-4 h-4 mr-2" />
                    Home Services Available
                  </Badge>
                )}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={salon.imageUrl || "https://images.unsplash.com/photo-1562322140-8baeececf3df?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"} 
                alt={salon.name}
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Services</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services?.map((service: Service) => (
              <Card key={service.id} className="group hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-bold text-gray-900 group-hover:text-primary transition-colors">
                      {service.name}
                    </h3>
                    <Badge variant="secondary">
                      ₹{service.price}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-600 mb-4">
                    {service.description || `Professional ${service.name.toLowerCase()} service`}
                  </p>
                  
                  <div className="flex items-center mb-4 text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-1" />
                    {service.duration} minutes
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      onClick={() => handleBookService(service)}
                      className="flex-1 bg-primary hover:bg-purple-700"
                      size="sm"
                    >
                      <Store className="w-4 h-4 mr-2" />
                      Book Salon Visit
                    </Button>
                    {salon.homeServiceAvailable && service.homeServicePrice && (
                      <Button 
                        onClick={() => handleBookService(service)}
                        variant="outline" 
                        className="flex-1"
                        size="sm"
                      >
                        <Home className="w-4 h-4 mr-2" />
                        Home (₹{service.homeServicePrice})
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Customer Reviews</h2>
          
          {reviewsLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white p-6 rounded-lg shadow">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : reviews && reviews.length > 0 ? (
            <div className="space-y-6">
              {reviews.map((review: any) => (
                <Card key={review.id} className="p-6">
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${i < review.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-500">
                      {new Date(review.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-gray-500">No reviews yet. Be the first to review this salon!</p>
            </Card>
          )}
        </div>
      </section>

      <Footer />
      
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        service={selectedService}
        salon={selectedSalon}
      />
    </div>
  );
}
