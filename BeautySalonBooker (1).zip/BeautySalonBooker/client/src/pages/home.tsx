import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import CategoryCards from "@/components/features/category-cards";
import SalonGrid from "@/components/features/salon-grid";
import QuickBook from "@/components/features/quick-book";

export default function Home() {
  const { user } = useAuth();
  const { data: categories } = useQuery({
    queryKey: ['/api/categories'],
  });

  useEffect(() => {
    document.title = "BeautySalon - Your Beauty Dashboard";
  }, []);

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Welcome Section */}
      <section className="pt-24 pb-12 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Welcome back, <span className="text-primary">{user?.firstName || 'Beautiful'}</span>!
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ready to book your next beauty appointment? Discover top-rated salons and services near you.
            </p>
          </div>
        </div>
      </section>

      {/* Quick Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Book Your Service</h2>
            <p className="text-lg text-gray-600">Choose from our popular beauty categories</p>
          </div>
          <CategoryCards />
        </div>
      </section>

      {/* Top Rated Stores in Your Area */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Top Rated Stores in Your Area</h2>
            <p className="text-lg text-gray-600">Discover the best beauty services near you</p>
          </div>
          
          {/* Men's Hair Salons */}
          <SalonGrid 
            categoryId={1} 
            title="Men's Hair Specialists" 
            showAll={false}
          />
          
          {/* Women's Beauty Salons */}
          <SalonGrid 
            categoryId={2} 
            title="Women's Beauty Experts" 
            showAll={false}
          />
          
          {/* Nail Studios */}
          <SalonGrid 
            categoryId={3} 
            title="Professional Nail Studios" 
            showAll={false}
          />
          
          {/* Makeup Artists */}
          <SalonGrid 
            categoryId={4} 
            title="Expert Makeup Artists" 
            showAll={false}
          />
        </div>
      </section>

      {/* Quick Book */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Available <span className="text-primary">Right Now</span>
            </h2>
            <p className="text-lg text-gray-600">Book instant appointments with immediate availability</p>
          </div>
          <QuickBook />
        </div>
      </section>

      <Footer />
    </div>
  );
}
