export interface SalonWithServices {
  id: number;
  name: string;
  description?: string;
  address: string;
  city: string;
  rating: string;
  reviewCount: number;
  imageUrl?: string;
  homeServiceAvailable: boolean;
  services: ServiceWithCategory[];
}

export interface ServiceWithCategory {
  id: number;
  name: string;
  description?: string;
  price: string;
  duration: number;
  homeServicePrice?: string;
  imageUrl?: string;
  category: {
    name: string;
    colorScheme: string;
  };
}

export interface CategoryWithServices {
  id: number;
  name: string;
  slug: string;
  description?: string;
  colorScheme: string;
  imageUrl?: string;
  services: ServiceWithCategory[];
}

export interface BookingFormData {
  serviceId: number;
  salonId: number;
  bookingDate: string;
  bookingTime: string;
  serviceType: 'salon' | 'home';
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  notes?: string;
}
