import {
  users,
  salons,
  categories,
  services,
  bookings,
  reviews,
  type User,
  type UpsertUser,
  type Salon,
  type Category,
  type Service,
  type Booking,
  type Review,
  type InsertSalon,
  type InsertCategory,
  type InsertService,
  type InsertBooking,
  type InsertReview,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Salon operations
  getSalons(): Promise<Salon[]>;
  getSalonById(id: number): Promise<Salon | undefined>;
  getSalonsByCategory(categoryId: number): Promise<Salon[]>;
  createSalon(salon: InsertSalon): Promise<Salon>;
  updateSalon(id: number, salon: Partial<InsertSalon>): Promise<Salon>;

  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Service operations
  getServices(): Promise<Service[]>;
  getServiceById(id: number): Promise<Service | undefined>;
  getServicesBySalon(salonId: number): Promise<Service[]>;
  getServicesByCategory(categoryId: number): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service>;

  // Booking operations
  getBookings(): Promise<Booking[]>;
  getBookingById(id: number): Promise<Booking | undefined>;
  getBookingsByUser(userId: string): Promise<Booking[]>;
  getBookingsBySalon(salonId: number): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: number, booking: Partial<InsertBooking>): Promise<Booking>;

  // Review operations
  getReviewsBySalon(salonId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Salon operations
  async getSalons(): Promise<Salon[]> {
    return await db.select().from(salons).where(eq(salons.isActive, true)).orderBy(desc(salons.rating));
  }

  async getSalonById(id: number): Promise<Salon | undefined> {
    const [salon] = await db.select().from(salons).where(and(eq(salons.id, id), eq(salons.isActive, true)));
    return salon;
  }

  async getSalonsByCategory(categoryId: number): Promise<Salon[]> {
    const result = await db
      .selectDistinct({
        id: salons.id,
        name: salons.name,
        description: salons.description,
        address: salons.address,
        city: salons.city,
        state: salons.state,
        pincode: salons.pincode,
        latitude: salons.latitude,
        longitude: salons.longitude,
        phone: salons.phone,
        email: salons.email,
        rating: salons.rating,
        reviewCount: salons.reviewCount,
        imageUrl: salons.imageUrl,
        ownerId: salons.ownerId,
        isActive: salons.isActive,
        homeServiceAvailable: salons.homeServiceAvailable,
        createdAt: salons.createdAt,
        updatedAt: salons.updatedAt,
      })
      .from(salons)
      .innerJoin(services, eq(services.salonId, salons.id))
      .where(and(eq(services.categoryId, categoryId), eq(salons.isActive, true)))
      .orderBy(desc(salons.rating));
    
    return result;
  }

  async createSalon(salon: InsertSalon): Promise<Salon> {
    const [newSalon] = await db.insert(salons).values(salon).returning();
    return newSalon;
  }

  async updateSalon(id: number, salon: Partial<InsertSalon>): Promise<Salon> {
    const [updatedSalon] = await db
      .update(salons)
      .set({ ...salon, updatedAt: new Date() })
      .where(eq(salons.id, id))
      .returning();
    return updatedSalon;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.name));
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  // Service operations
  async getServices(): Promise<Service[]> {
    return await db.select().from(services).where(eq(services.isActive, true)).orderBy(asc(services.name));
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(and(eq(services.id, id), eq(services.isActive, true)));
    return service;
  }

  async getServicesBySalon(salonId: number): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(and(eq(services.salonId, salonId), eq(services.isActive, true)))
      .orderBy(asc(services.name));
  }

  async getServicesByCategory(categoryId: number): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(and(eq(services.categoryId, categoryId), eq(services.isActive, true)))
      .orderBy(asc(services.price));
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: number, service: Partial<InsertService>): Promise<Service> {
    const [updatedService] = await db
      .update(services)
      .set({ ...service, updatedAt: new Date() })
      .where(eq(services.id, id))
      .returning();
    return updatedService;
  }

  // Booking operations
  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingsByUser(userId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId)).orderBy(desc(bookings.bookingDate));
  }

  async getBookingsBySalon(salonId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.salonId, salonId)).orderBy(desc(bookings.bookingDate));
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async updateBooking(id: number, booking: Partial<InsertBooking>): Promise<Booking> {
    const [updatedBooking] = await db
      .update(bookings)
      .set({ ...booking, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  // Review operations
  async getReviewsBySalon(salonId: number): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.salonId, salonId)).orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }
}

export const storage = new DatabaseStorage();
