import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertSalonSchema, insertServiceSchema, insertBookingSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Category routes
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategoryById(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.get('/api/categories/slug/:slug', async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  // Salon routes
  app.get('/api/salons', async (req, res) => {
    try {
      const { categoryId } = req.query;
      let salons;
      
      if (categoryId) {
        salons = await storage.getSalonsByCategory(parseInt(categoryId as string));
      } else {
        salons = await storage.getSalons();
      }
      
      res.json(salons);
    } catch (error) {
      console.error("Error fetching salons:", error);
      res.status(500).json({ message: "Failed to fetch salons" });
    }
  });

  app.get('/api/salons/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const salon = await storage.getSalonById(id);
      if (!salon) {
        return res.status(404).json({ message: "Salon not found" });
      }
      res.json(salon);
    } catch (error) {
      console.error("Error fetching salon:", error);
      res.status(500).json({ message: "Failed to fetch salon" });
    }
  });

  app.post('/api/salons', isAuthenticated, async (req: any, res) => {
    try {
      const salonData = insertSalonSchema.parse(req.body);
      salonData.ownerId = req.user.claims.sub;
      const salon = await storage.createSalon(salonData);
      res.status(201).json(salon);
    } catch (error) {
      console.error("Error creating salon:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid salon data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create salon" });
    }
  });

  // Service routes
  app.get('/api/services', async (req, res) => {
    try {
      const { salonId, categoryId } = req.query;
      let services;
      
      if (salonId) {
        services = await storage.getServicesBySalon(parseInt(salonId as string));
      } else if (categoryId) {
        services = await storage.getServicesByCategory(parseInt(categoryId as string));
      } else {
        services = await storage.getServices();
      }
      
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get('/api/services/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const service = await storage.getServiceById(id);
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      res.json(service);
    } catch (error) {
      console.error("Error fetching service:", error);
      res.status(500).json({ message: "Failed to fetch service" });
    }
  });

  app.post('/api/services', isAuthenticated, async (req, res) => {
    try {
      const serviceData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(serviceData);
      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating service:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create service" });
    }
  });

  // Booking routes
  app.get('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookings = await storage.getBookingsByUser(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get('/api/bookings/salon-owner/:ownerId', isAuthenticated, async (req: any, res) => {
    try {
      const ownerId = req.params.ownerId;
      // For now, return empty array - in real implementation, get bookings for owner's salons
      res.json([]);
    } catch (error) {
      console.error("Error fetching salon owner bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get('/api/bookings/provider/:providerId', isAuthenticated, async (req: any, res) => {
    try {
      const providerId = req.params.providerId;
      // For now, return empty array - in real implementation, get bookings for service provider
      res.json([]);
    } catch (error) {
      console.error("Error fetching provider bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get('/api/salons/owner/:ownerId', isAuthenticated, async (req: any, res) => {
    try {
      const ownerId = req.params.ownerId;
      // For now, return empty array - in real implementation, get salons owned by user
      res.json([]);
    } catch (error) {
      console.error("Error fetching owner salons:", error);
      res.status(500).json({ message: "Failed to fetch salons" });
    }
  });

  app.get('/api/services/owner/:ownerId', isAuthenticated, async (req: any, res) => {
    try {
      const ownerId = req.params.ownerId;
      // For now, return empty array - in real implementation, get services for owner's salons
      res.json([]);
    } catch (error) {
      console.error("Error fetching owner services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get('/api/bookings/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBookingById(id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      res.json(booking);
    } catch (error) {
      console.error("Error fetching booking:", error);
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  app.post('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      bookingData.userId = req.user.claims.sub;
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Review routes
  app.get('/api/salons/:salonId/reviews', async (req, res) => {
    try {
      const salonId = parseInt(req.params.salonId);
      const reviews = await storage.getReviewsBySalon(salonId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      reviewData.userId = req.user.claims.sub;
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
