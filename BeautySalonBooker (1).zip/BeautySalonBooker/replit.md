# BeautySalon - Comprehensive Beauty Service Booking Platform

## Overview

BeautySalon is a comprehensive beauty salon booking platform that connects customers with professional beauty service providers across multiple categories. The application supports both salon visits and home service bookings, featuring a modern React frontend with a Node.js/Express backend, PostgreSQL database via Drizzle ORM, and Replit authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a modern full-stack architecture with clear separation between client and server:

- **Frontend**: React 18 with TypeScript, built using Vite
- **Backend**: Node.js with Express.js API server
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Replit-based OpenID Connect authentication
- **Styling**: Tailwind CSS with shadcn/ui component library

### Directory Structure
```
├── client/           # React frontend application
├── server/           # Express.js backend API
├── shared/           # Shared types and database schema
└── attached_assets/  # Project requirements and assets
```

## Key Components

### Frontend Architecture
- **Component Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens for category-specific theming
- **State Management**: React Query for server state, React Context for authentication
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **API Design**: RESTful API with Express.js
- **Database Layer**: Drizzle ORM with PostgreSQL, using connection pooling via Neon serverless
- **Authentication**: JWT-based sessions with OpenID Connect via Replit
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple

### Database Schema
Key entities include:
- **Users**: Customer profiles with role-based access (customer, salon_owner, service_provider)
- **Categories**: Service categories (Men's Hair, Women's Beauty, Nail Studios, Makeup Artists)
- **Salons**: Beauty service providers with location and contact information
- **Services**: Individual services offered by salons with pricing and duration
- **Bookings**: Appointment scheduling with support for both salon and home services
- **Reviews**: Customer feedback and rating system

## Data Flow

### Authentication Flow
1. Replit OpenID Connect handles user authentication
2. JWT tokens stored in HTTP-only cookies for security
3. Session data persisted in PostgreSQL for scalability
4. Frontend queries user state via React Query

### Booking Flow
1. Customer browses services by category or salon
2. Service selection opens booking modal with form validation
3. Booking data submitted via API with business rule validation
4. Email confirmations sent to customer and service provider
5. Real-time booking status updates via optimistic UI updates

### Service Discovery
1. Categories loaded on application start
2. Services filtered by category, location, or salon
3. Real-time availability checking for booking slots
4. Image optimization for performance

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection and pooling
- **drizzle-orm**: Type-safe database ORM with migrations
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI component primitives
- **express**: Web application framework
- **passport**: Authentication middleware

### Authentication
- **openid-client**: OpenID Connect client implementation
- **connect-pg-simple**: PostgreSQL session store
- **memoizee**: Function memoization for performance

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Type checking and development experience
- **tailwindcss**: Utility-first CSS framework
- **drizzle-kit**: Database migration and schema management

## Deployment Strategy

### Development Environment
- Vite development server with HMR for frontend
- tsx for TypeScript execution in development
- Replit integration with development banner and cartographer

### Production Build
- Vite builds optimized frontend bundle to `dist/public`
- esbuild bundles server code for Node.js execution
- Static file serving integrated with Express for single-server deployment

### Database Management
- Drizzle migrations for schema versioning
- Environment-based database URL configuration
- Connection pooling for performance and reliability

### Security Considerations
- HTTP-only cookies for session management
- CORS configuration for cross-origin requests
- Input validation using Zod schemas
- SQL injection prevention via parameterized queries

The architecture supports horizontal scaling through stateless API design and external session storage, making it suitable for cloud deployment platforms.